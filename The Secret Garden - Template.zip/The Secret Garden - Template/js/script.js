//MAKE THE MAGIC HAPPEN
function swapImages() {
    var $active = $('#daynnight .active');
    var $next = ($('#daynnight .active').next().length > 0) ? $('#daynnight .active').next() : $('#daynnight img:first');
    $active.fadeOut(function () {
        $active.removeClass('active');
        $next.fadeIn().addClass('active');
    });
}

 function animate_loop() {
            $('#night').animate({'opacity':0.8}, 35000),
            $('#day').animate({'opacity':0}, 25000),
            $('#night').animate({'opacity':0}, 25000),
            $('#day').animate({'opacity':1}, 35000),
             function(){
                        animate_loop();
            };
    }




var t = 0;

function moveit() {
    t += 0.0025;

    var r = $(window).width() / 2;
    var xcenter = ($(window).width() / 2);
    var ycenter = $(window).height();
    var newLeft = Math.floor(xcenter + (r * Math.cos(t)));
    var newTop = Math.floor(ycenter + (r * Math.sin(t)));

    $('#daynnight .active').animate({
        top: newTop,
        left: newLeft,
    }, 1, function () {
        moveit();
    });
}


$(document).ready(function () {
    moveit();
    setInterval('swapImages()', 22000);
    animate_loop();
});